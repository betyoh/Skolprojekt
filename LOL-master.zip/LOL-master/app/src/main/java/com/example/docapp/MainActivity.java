package com.example.docapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private Button logout;
    private Button goTo;
    private TextView tips;
    private Button show;

    /*private FirebaseAuth fAuth;*/

    FirebaseDatabase database;
    DatabaseReference showinfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logout = findViewById(R.id.logout);
        goTo = findViewById(R.id.togo);
        tips = findViewById(R.id.tipss);
        show = findViewById(R.id. showdata);

        database =FirebaseDatabase.getInstance();
        showinfo = database.getReference("Tips");

        //gData = new Firebase("https://docapp-f2134.firebaseio.com/");

        //fAuth =FirebaseAuth.getInstance();
        /*UpdateUI();*/

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               //tips = (TextView) tips.getText();

               showinfo.addValueEventListener(new ValueEventListener() {
                   @Override
                   public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                       Tips userTips = dataSnapshot.getValue(Tips.class);


                   }
                   @Override
                   public void onCancelled(@NonNull DatabaseError databaseError) {

                   }
               });
            }
        });





        goTo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddActivity.class));

            }

        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Toast.makeText(MainActivity.this, "Logged Out!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent (MainActivity.this,StartActivity.class);
                startActivity(intent);
            }

        });


    }

   /* private void UpdateUI() {
        if(fAuth.getCurrentUser()!= null)
        {
            Log.i("MainActivity", "fAuth== null");
        }
        else {
            Intent intent = new Intent(MainActivity.this,StartActivity.class);
            startActivity(intent);
            finish();
            Log.i("MainActivity", "fAuth== null");
        }
    }*/


}
