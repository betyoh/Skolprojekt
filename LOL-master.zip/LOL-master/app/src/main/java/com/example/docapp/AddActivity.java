package com.example.docapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.security.PublicKey;
import java.util.HashMap;
import java.util.Map;

public class AddActivity extends AppCompatActivity {


    private ImageButton add;
    private EditText write;
    private EditText name;

    //private FirebaseFirestore firestore;
    private FirebaseAuth auth;
    private DatabaseReference refNote;
    //private String userID;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        write = (EditText) findViewById(R.id.tipstext);
        name = (EditText) findViewById(R.id.regName);
        add = (ImageButton) findViewById(R.id.addButton);

        //firestore = FirebaseFirestore.getInstance();

        auth = FirebaseAuth.getInstance();
        refNote = FirebaseDatabase.getInstance().getReference().child("Tips").child(auth.getCurrentUser().getUid());



        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String writeTips = write.getText().toString();
                String nameText = name.getText().toString();

                if (!TextUtils.isEmpty(writeTips)){
                    saveTips(writeTips, nameText);
                }
                else{
                    Toast.makeText(AddActivity.this, "Add story!", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    public void saveTips(String writeTips, String nameText) {
        if(auth.getCurrentUser() !=null ){
            final DatabaseReference infoRef = refNote.push();
            final Map tipsMap = new HashMap();
            tipsMap.put("Tips",writeTips);
            tipsMap.put("Name",nameText);
            //tipsMap.put("info", ServerValue.TIMESTAMP);



            infoRef.setValue(tipsMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {

                    if(task.isSuccessful()){
                      Toast.makeText(AddActivity.this,"Tips is added!",Toast.LENGTH_SHORT).show();
                  }
                  else {
                      Toast.makeText(AddActivity.this,"Error" + task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                  }
                }
            });

        }

    }

}







