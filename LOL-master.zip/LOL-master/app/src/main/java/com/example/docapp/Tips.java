package com.example.docapp;

public class Tips {

    private String tips;
    private String name;

    public Tips() {
    }


    public String getTips() {
        return tips;
    }

    public void setTips(String tips) {
        this.tips = tips;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}



