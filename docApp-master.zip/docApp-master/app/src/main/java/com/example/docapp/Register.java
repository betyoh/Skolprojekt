package com.example.docapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {

    private EditText name;
    private EditText email;
    private EditText password;
    private Button register;

    private FirebaseAuth auth;
    private FirebaseFirestore firestore;
    private String userID;

    public static String TAG = "TAG";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name = findViewById(R.id.regName);
        email = findViewById(R.id.regEmail);
        password = findViewById(R.id.regPass);
        register = findViewById(R.id.idregister);

        auth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String txt_name = name.getText().toString();
                String txt_email = email.getText().toString();
                String txt_password = password.getText().toString();

                if(TextUtils.isEmpty(txt_email) || TextUtils.isEmpty(txt_password))
                {
                    Toast.makeText(Register.this, "Error!", Toast.LENGTH_SHORT).show();
                }
                else if(txt_password.length()< 6)
                {
                     Toast.makeText(Register.this,"Password is too short!", Toast.LENGTH_SHORT).show();
                }
                else{
                    registerUser(txt_name,txt_email, txt_password);
                }

            }
        });
    }

    private void registerUser(final String name, final String email, String password) {

        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(Register.this,"Successful registration!", Toast.LENGTH_SHORT).show();
                    userID = auth.getCurrentUser().getUid();
                    DocumentReference docref = firestore.collection("users").document(userID);
                    Map<String,Object> user = new HashMap<>();
                    user.put("name", name);
                    user.put("email", email);
                    docref.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG,"Your profile is created " + userID);

//                            Intent intent = new Intent (Register.this,MainActivity.class);
//                            startActivity(intent);
//                            finish();
                        }
                    });
                    Intent intent = new Intent (Register.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }
                else {
                    Toast.makeText(Register.this, "Registration fail!", Toast.LENGTH_SHORT).show();
                }


            }
        });


    }


}
